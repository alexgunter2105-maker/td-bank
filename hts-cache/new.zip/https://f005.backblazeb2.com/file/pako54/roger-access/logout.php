{
  "code": "not_found",
  "message": "File with such name does not exist.",
  "status": 404
}